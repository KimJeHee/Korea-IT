package project;

import java.util.Scanner;

public class main2 {

	public static void main(String[] args) {

		String Apt = "Summit"; // 아파트 이름
		String truePW = "1234"; // 공동 현관비밀번호
		String trueDeveloperPW = "#999936"; // 관리자용 비밀번호
		String PW;  
		
		Scanner scan = new Scanner(System.in);
		System.out.println(Apt + "아파트에 오신걸 환영합니다!");

		do {
			System.out.print("비밀번호를 입력하세요:");
			PW = scan.next();
			if (!((PW.equals(truePW)) || PW.equals(trueDeveloperPW))) {
				System.out.println("공동 현관번호가 틀립니다.");
			} else {
				System.out.println("문이 열립니다.");
				break;
			}
		} while (true);
	}
}